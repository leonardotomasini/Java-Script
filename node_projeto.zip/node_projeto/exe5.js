const http = require('http');
const fs = require('fs');
const querystring = require('querystring');
const ARQUIVO_JSON = 'mensagens.json';
let mensagens = [];
if (fs.existsSync(ARQUIVO_JSON)) {
    mensagens = JSON.parse(fs.readFileSync(ARQUIVO_JSON));
} else {
    fs.writeFileSync(ARQUIVO_JSON, '[]');
}
const server = http.createServer((req, res) => {
    if (req.url === '/' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(`
<!DOCTYPE html>
<html>
<head>
    <title>Chat Sem Refresh</title>
    <style>
        body {
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
        }
        #form {
            display: flex;
            gap: 10px;
        }
        #mensagem {
            flex: 1;
            padding: 8px;
        }
        button {
            padding: 8px 20px;
            background: #28a745;
            color: white;
            border: none;
        }
    </style>
</head>
<body>
    <h2>Enviar Mensagem</h2>
    <form id="form">
        <input type="text" id="mensagem" placeholder="Digite sua mensagem..." required>
        <button type="submit">Enviar</button>
    </form>
    <script>
        document.getElementById('form').addEventListener('submit', function(e) {
            e.preventDefault();
            const input = document.getElementById('mensagem');
            const mensagem = input.value.trim();
            if (!mensagem) return;
            fetch('/salvar', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: 'mensagem=' + encodeURIComponent(mensagem)
            }).then(() => input.value = '');
        });
    </script>
</body>
</html>
        `);
    }
    else if (req.url === '/salvar' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const { mensagem } = querystring.parse(body);
            
            if (mensagem && mensagem.trim()) {
                mensagens.push({
                    texto: mensagem.trim(),
                    data: new Date().toISOString()
                }); 
                fs.writeFile(ARQUIVO_JSON, JSON.stringify(mensagens, null, 2), (err) => {
                    if (err) {
                        res.writeHead(500);
                        return res.end('Erro ao salvar');
                    }
                    res.writeHead(200);
                    res.end();
                });
            } else {
                res.writeHead(400);
                res.end('Mensagem inválida');
            }
        });
    }
    else {
        res.writeHead(404);
        res.end();
    }
});
server.listen(3004, () => console.log('Servidor rodando em http://localhost:3004'));