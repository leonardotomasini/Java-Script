const http = require('http');
const url = require('url');
const querystring = require('querystring');
const server = http.createServer((req, res) => {
    const { pathname } = url.parse(req.url);
    if (pathname === '/' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Cálculo de Aumento</title>
                <style>
                    body { font-family: Arial; max-width: 400px; margin: 20px auto; padding: 20px; }
                    form { display: grid; gap: 10px; }
                    input, button { padding: 8px; }
                    .result { margin-top: 20px; padding: 10px; }
                </style>
            </head>
            <body>
                <h2>Calculadora de Aumento</h2>
                <form action="/calcular" method="POST">
                    <input type="number" name="salario" step="0.01" placeholder="Salário atual (R$)" required>
                    <input type="number" name="aumento" step="0.01" placeholder="Valor do aumento (R$)" required>
                    <button type="submit">Calcular</button>
                </form>
            </body>
            </html>
        `);
    }
    else if (pathname === '/calcular' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk.toString());
        req.on('end', () => {
            const { salario, aumento } = querystring.parse(body);
            const salarioNum = parseFloat(salario);
            const aumentoNum = parseFloat(aumento);
            const novoSalario = salarioNum + aumentoNum;
            const porcentagem = (aumentoNum / salarioNum) * 100;
            res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
            res.end(`
                <html>
                <body style="max-width: 400px; margin: 20px auto; padding: 20px;">
                    <div class="result">
                        <h3>Resultado:</h3>
                        <p>Salário original: R$ ${salarioNum.toFixed(2)}</p>
                        <p>Aumento: R$ ${aumentoNum.toFixed(2)} (${porcentagem.toFixed(2)}%)</p>
                        <p><strong>Novo salário: R$ ${novoSalario.toFixed(2)}</strong></p>
                        <a href="/">Voltar</a>
                    </div>
                </body>
                </html>
            `);
        });
    }  
    else {
        res.writeHead(404);
        res.end('Página não encontrada');
    }
});
server.listen(3003, () => console.log('Servidor rodando em http://localhost:3003'));