const http = require("http");
const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    const htmlContent = `
    <!DOCTYPE html>
    <html>
    <head>
        <title>Bem-vindo</title>
        <style>
            h1 {
                text-align: center;
            }
        </style>
    </head>
    <body>
        <h1>Olá! Servidor na porta 3001 </h1>
    </body>
    </html>
    `;
    res.end(htmlContent);
});
server.listen(3001, 'localhost', () => {
    console.log('Acesse: http://localhost:3001');
});