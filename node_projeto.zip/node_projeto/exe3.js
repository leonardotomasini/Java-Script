const http = require('http');
const url = require('url');
const querystring = require('querystring');
const server = http.createServer((req, res) => {
    const parsedUrl = url.parse(req.url);
    if (parsedUrl.pathname === '/' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(`
            <!DOCTYPE html>
            <html>
            <head>
                <title>Login Simples</title>
                <style>
                    form { width: 200px; margin: 50px auto; }
                    input { display: block; margin: 10px 0; padding: 5px; }
                </style>
            </head>
            <body>
                <form action="/login" method="POST">
                    <input type="text" name="username" placeholder="Usuário" required>
                    <input type="password" name="password" placeholder="Senha" required>
                    <button>Entrar</button>
                </form>
            </body>
            </html>
        `);
    }
    else if (parsedUrl.pathname === '/login' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
        });
        req.on('end', () => {
            const formData = querystring.parse(body);
            res.writeHead(302, {
                'Location': `/welcome?username=${encodeURIComponent(formData.username)}`
            });
            res.end();
        });
    }
    else if (parsedUrl.pathname === '/welcome') {
        const query = querystring.parse(parsedUrl.query);
        const username = query.username || 'Visitante';
        res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
        res.end(`
            <!DOCTYPE html>
            <html>
            <head>
                <style>
                    body {
                        text-align: center;
                        padding: 2rem;
                    }
                </style>
            </head>
            <body>
                <h1>Bem-vindo, ${username}!</h1>
                <p>Login fake realizado.</p>
            </body>
            </html>
        `);
    }
    else {
        res.writeHead(404);
        res.end('Página não encontrada');
    }
});
server.listen(3002, () => {
    console.log('Servidor rodando em http://localhost:3002');
});