const http = require("http")
const servidor = http.createServer((req,res)=> {
    res.write("Hello World")
    res.end()
})
servidor.listen(3000, 'localhost', ()=>console.log("Servidor logado"))