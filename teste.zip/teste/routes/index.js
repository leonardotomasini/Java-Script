var express = require('express');
var router = express.Router();
const fs = require('fs');
const path = require('path');

router.get('/', function(req, res) {
  res.render('index', { titulo: 'Página Inicial' });
});

router.get('/pagina1', function(req, res) {
  res.send('hello world');
});

router.get('/pagina2', function(req, res) {
  res.render('pagina2', { nome: null });
});
router.post('/pagina2', function(req, res) {
  const nome = req.body.username;
  res.render('pagina2', { nome });
});

router.route('/pagina3')
  .get((req, res) => res.render('pagina3', { nome: null }))
  .post((req, res) => {
    const nome = req.body.username;
    res.render('pagina3', { nome });
  });


//nao entendia como fazia essa direito no express e no JS, precisei do chat pra rodar essa parte do código
router.get('/pagina4', (req, res) =>
  res.render('pagina4', { erro: null, salario: '', aumento: '', novoSalario: null, porcentagem: null })
);
router.post('/pagina4', (req, res) => {
  const s = parseFloat(req.body.salario), a = parseFloat(req.body.aumento);
  if (isNaN(s) || isNaN(a) || s < 0 || a < 0)
    return res.render('pagina4', { erro: 'Por favor, informe números válidos e positivos', salario: req.body.salario, aumento: req.body.aumento, novoSalario: null, porcentagem: null });

  res.render('pagina4', { erro: null, salario: s, aumento: a, novoSalario: s + a, porcentagem: (a / s) * 100 });
});


//não fazia ideia nem por onde começar essa daqui no express, usei o chat mas tentei entender o que cada coisa fazia (até porque o chat não conseguiu fazer de primeira também kkk)
router.get('/pagina5', (req, res) => {
  res.render('pagina5');
});

router.post('/pagina5', (req, res) => {
  const texto = req.body.texto;
  const arquivo = path.join(__dirname, '../mensagens.json');
  fs.readFile(arquivo, 'utf8', (err, data) => {
    let mensagens = [];
    if (!err && data) {
      try {
        mensagens = JSON.parse(data);
      } catch (e) {
        mensagens = [];
      }
    }
    mensagens.push({ texto, data: new Date().toISOString() });

    fs.writeFile(arquivo, JSON.stringify(mensagens, null, 2), err => {
      if (err) {
        return res.status(500).json({ erro: 'Erro ao salvar a mensagem' });
      }
      res.json({ sucesso: true });
    });
  });
});
module.exports = router;
